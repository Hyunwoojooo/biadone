
  # Extraction Monitoring Console UI

  This is a code bundle for Extraction Monitoring Console UI. The original project is available at https://www.figma.com/design/195RJXz68b7oEgIxBX2g0y/Extraction-Monitoring-Console-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  